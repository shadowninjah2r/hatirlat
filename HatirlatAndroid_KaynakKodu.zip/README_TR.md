# Hatırlat (Android)

Mor-siyah temalı, tarih/saat seçerek hatırlatma kuran örnek Android Studio projesi.

## APK oluşturma
1. Bilgisayara Android Studio kur.
2. Bu ZIP dosyasını çıkar ve Android Studio'da `HatirlatAndroid` klasörünü aç.
3. Gradle senkronizasyonunun bitmesini bekle.
4. `Build > Build Bundle(s) / APK(s) > Build APK(s)` seç.
5. APK genellikle `app/build/outputs/apk/debug/app-debug.apk` konumunda oluşur.

## Telefonda izinler
- Bildirim iznini ver.
- Uygulamadaki **ALARM / TAM EKRAN İZİNLERİ** düğmesine basıp izinleri aç.
- Telefon ayarlarında Hatırlat için tam ekran bildirim ve tam zamanında alarm iznini etkinleştir.
- Bazı üreticiler pil tasarrufu nedeniyle arka plan alarmlarını kısıtlayabilir.

## Not
Android'in güvenlik kuralları nedeniyle tam ekran açılır hatırlatma her cihazda otomatik olarak garanti edilemez. Uygulama, Android'in tam ekran bildirim mekanizmasını kullanır. Android 14+ sürümlerinde tam ekran bildirim izni kullanıcı tarafından verilmelidir.
