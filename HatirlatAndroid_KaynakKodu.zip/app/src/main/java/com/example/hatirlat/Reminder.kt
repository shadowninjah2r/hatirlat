package com.example.hatirlat

import org.json.JSONObject

data class Reminder(val id: Int, val title: String, val note: String, val time: Long) {
    fun toJson() = JSONObject().put("id", id).put("title", title)
        .put("note", note).put("time", time)

    companion object {
        fun fromJson(o: JSONObject) = Reminder(
            o.getInt("id"), o.getString("title"),
            o.optString("note"), o.getLong("time")
        )
    }
}
