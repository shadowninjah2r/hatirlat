package com.example.hatirlat

import android.content.Context
import org.json.JSONArray

object ReminderStore {
    private const val PREFS = "hatirlat_data"
    private const val KEY = "reminders"

    fun all(context: Context): MutableList<Reminder> {
        val raw = context.getSharedPreferences(PREFS, 0).getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(raw)
        return MutableList(arr.length()) { i -> Reminder.fromJson(arr.getJSONObject(i)) }
    }

    fun save(context: Context, items: List<Reminder>) {
        val arr = JSONArray()
        items.forEach { arr.put(it.toJson()) }
        context.getSharedPreferences(PREFS, 0).edit().putString(KEY, arr.toString()).apply()
    }
}
