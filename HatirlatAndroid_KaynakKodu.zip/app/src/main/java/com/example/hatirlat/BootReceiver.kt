package com.example.hatirlat

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            ReminderStore.all(context).forEach {
                if (it.time > System.currentTimeMillis()) AlarmScheduler.schedule(context, it)
            }
        }
    }
}
