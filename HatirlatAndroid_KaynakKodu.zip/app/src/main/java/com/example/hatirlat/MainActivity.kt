package com.example.hatirlat

import android.Manifest
import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 7, 18)
    private val panel = Color.rgb(31, 23, 43)
    private val purple = Color.rgb(151, 75, 235)
    private var chosenTime = System.currentTimeMillis() + 60_000
    private lateinit var timeLabel: TextView
    private lateinit var listBox: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermission()
        createChannel()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 32, 24, 24)
            setBackgroundColor(bg)
        }
        val title = TextView(this).apply {
            text = "HATIRLAT"
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(198, 143, 255))
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Zamanını unutma. Kontrol sende."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 4, 0, 24)
        }
        val name = EditText(this).apply {
            hint = "Hatırlatma başlığı"
            setHintTextColor(Color.LTGRAY); setTextColor(Color.WHITE)
            setSingleLine(true); setPadding(16, 12, 16, 12)
            setBackgroundColor(panel)
        }
        val note = EditText(this).apply {
            hint = "Açıklama (isteğe bağlı)"
            setHintTextColor(Color.LTGRAY); setTextColor(Color.WHITE)
            setPadding(16, 12, 16, 12); setBackgroundColor(panel)
        }
        timeLabel = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 16f
            gravity = Gravity.CENTER; setPadding(8, 18, 8, 18)
        }
        val pick = button("TARİH VE SAAT SEÇ", Color.rgb(75, 49, 105))
        pick.setOnClickListener { chooseDateTime() }
        val add = button("＋ HATIRLATICI EKLE", purple)
        add.setOnClickListener {
            val text = name.text.toString().trim()
            if (text.isEmpty()) {
                Toast.makeText(this, "Bir başlık yazmalısın.", Toast.LENGTH_SHORT).show()
            } else if (chosenTime <= System.currentTimeMillis()) {
                Toast.makeText(this, "Gelecekte bir zaman seç.", Toast.LENGTH_SHORT).show()
            } else {
                val item = Reminder((System.currentTimeMillis() % Int.MAX_VALUE).toInt(),
                    text, note.text.toString().trim(), chosenTime)
                val items = ReminderStore.all(this)
                items.add(item); ReminderStore.save(this, items)
                AlarmScheduler.schedule(this, item)
                name.setText(""); note.setText("")
                Toast.makeText(this, "Hatırlatma kaydedildi.", Toast.LENGTH_SHORT).show()
                renderList()
            }
        }
        val permission = button("ALARM / TAM EKRAN İZİNLERİ", Color.rgb(65, 44, 88))
        permission.setOnClickListener { openAlarmSettings() }
        val listTitle = TextView(this).apply {
            text = "KAYITLI HATIRLATMALAR"
            setTextColor(Color.rgb(198, 143, 255))
            textSize = 17f; typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 26, 0, 12)
        }
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(title); root.addView(subtitle)
        root.addView(name, fieldParams()); root.addView(note, fieldParams())
        root.addView(timeLabel); root.addView(pick, fieldParams())
        root.addView(add, fieldParams()); root.addView(permission, fieldParams())
        root.addView(listTitle); root.addView(listBox)
        setContentView(ScrollView(this).apply { addView(root) })
        updateTimeLabel(); renderList()
    }

    private fun fieldParams() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = 10 }
    private fun button(text: String, color: Int) = Button(this).apply {
        this.text = text; isAllCaps = false; textSize = 14f
        setTextColor(Color.WHITE); setBackgroundColor(color)
    }

    private fun chooseDateTime() {
        val cal = Calendar.getInstance()
        DatePickerDialog(this, { _, y, m, d ->
            cal.set(y, m, d)
            TimePickerDialog(this, { _, h, min ->
                cal.set(Calendar.HOUR_OF_DAY, h); cal.set(Calendar.MINUTE, min)
                cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
                chosenTime = cal.timeInMillis
                updateTimeLabel()
            }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun updateTimeLabel() {
        timeLabel.text = "Seçilen zaman: " +
            SimpleDateFormat("dd.MM.yyyy  HH:mm", Locale.getDefault()).format(Date(chosenTime))
    }

    private fun renderList() {
        listBox.removeAllViews()
        ReminderStore.all(this).sortedBy { it.time }.forEach { item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(16, 12, 16, 12)
                setBackgroundColor(panel)
            }
            val label = TextView(this).apply {
                text = item.title + "\n" + SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(item.time))
                setTextColor(Color.WHITE); textSize = 16f
            }
            val del = button("SİL", Color.rgb(100, 39, 75))
            del.setOnClickListener {
                AlarmScheduler.cancel(this, item.id)
                ReminderStore.save(this, ReminderStore.all(this).filterNot { it.id == item.id })
                renderList()
            }
            row.addView(label); row.addView(del)
            listBox.addView(row, fieldParams())
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("reminders", "Hatırlatmalar", NotificationManager.IMPORTANCE_HIGH)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun openAlarmSettings() {
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                    Uri.parse("package:$packageName")))
            } else if (Build.VERSION.SDK_INT >= 31) {
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                    Uri.parse("package:$packageName")))
            } else {
                Toast.makeText(this, "Bu Android sürümünde özel alarm izni gerekmiyor.", Toast.LENGTH_LONG).show()
            }
        } catch (_: Exception) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
    }
}
