package com.example.hatirlat

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface
import android.content.Context
import android.app.PendingIntent
import android.content.Intent
import android.app.AlarmManager
import android.os.Build

class ReminderActivity : Activity() {
    private val bg = Color.rgb(10, 7, 18)
    private val purple = Color.rgb(151, 75, 235)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )

        val id = intent.getIntExtra("id", 1)
        val title = intent.getStringExtra("title") ?: "Hatırlatma!"
        val note = intent.getStringExtra("note") ?: ""

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 48, 32, 48)
            setBackgroundColor(bg)
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 40, 28, 32)
            setBackgroundColor(Color.rgb(35, 25, 51))
        }
        val icon = TextView(this).apply {
            text = "◈"
            textSize = 48f
            setTextColor(Color.rgb(195, 137, 255))
            gravity = Gravity.CENTER
        }
        val heading = TextView(this).apply {
            text = "HATIRLATMA!"
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(194, 145, 255))
            gravity = Gravity.CENTER
        }
        val message = TextView(this).apply {
            text = title
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 14)
        }
        val detail = TextView(this).apply {
            text = note
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 30)
        }
        val done = makeButton("TAMAM", purple)
        done.setOnClickListener {
            ReminderStore.save(this, ReminderStore.all(this).filterNot { it.id == id })
            AlarmScheduler.cancel(this, id)
            finish()
        }
        val snooze = makeButton("10 DAKİKA ERTELE", Color.rgb(73, 51, 99))
        snooze.setOnClickListener {
            val updated = Reminder(id, title, note, System.currentTimeMillis() + 10 * 60 * 1000)
            val list = ReminderStore.all(this).filterNot { it.id == id }.toMutableList()
            list.add(updated)
            ReminderStore.save(this, list)
            AlarmScheduler.schedule(this, updated)
            finish()
        }
        card.addView(icon); card.addView(heading); card.addView(message); card.addView(detail)
        card.addView(done, buttonParams()); card.addView(snooze, buttonParams())
        root.addView(card, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    private fun makeButton(text: String, color: Int) = Button(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        setBackgroundColor(color)
        textSize = 14f
        isAllCaps = false
    }

    private fun buttonParams() = LinearLayout.LayoutParams(-1, 58).apply {
        topMargin = 12
    }
}
